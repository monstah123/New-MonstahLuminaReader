
import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import FlashcardSection from './components/FlashcardSection';
import OpenersSection from './components/OpenersSection';
import StoriesSection from './components/StoriesSection';
import DashboardSection from './components/DashboardSection';
import PersonalTrainingSection from './components/PersonalTrainingSection'; // New import

type Section = 'flashcards' | 'openers' | 'stories' | 'dashboard' | 'personal-training'; // Updated type

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>('flashcards');

  const renderSection = () => {
    switch (activeSection) {
      case 'flashcards':
        return <FlashcardSection />;
      case 'openers':
        return <OpenersSection />;
      case 'stories':
        return <StoriesSection />;
      case 'dashboard':
        return <DashboardSection />;
      case 'personal-training': // New case
        return <PersonalTrainingSection />;
      default:
        return <FlashcardSection />;
    }
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1 className="app-title">Monstah Edge: Sales & Coaching Playbook</h1> {/* Updated title */}
        <nav className="main-nav" aria-label="Main Navigation">
          <button
            className={`nav-button ${activeSection === 'flashcards' ? 'active' : ''}`}
            onClick={() => setActiveSection('flashcards')}
            aria-current={activeSection === 'flashcards' ? 'page' : undefined}
          >
            Objections Flashcards
          </button>
          <button
            className={`nav-button ${activeSection === 'openers' ? 'active' : ''}`}
            onClick={() => setActiveSection('openers')}
            aria-current={activeSection === 'openers' ? 'page' : undefined}
          >
            Openers
          </button>
          <button
            className={`nav-button ${activeSection === 'stories' ? 'active' : ''}`}
            onClick={() => setActiveSection('stories')}
            aria-current={activeSection === 'stories' ? 'page' : undefined}
          >
            Product Storytelling
          </button>
          <button
            className={`nav-button ${activeSection === 'personal-training' ? 'active' : ''}`}
            onClick={() => setActiveSection('personal-training')}
            aria-current={activeSection === 'personal-training' ? 'page' : undefined}
          >
            Personal Training
          </button>
          <button
            className={`nav-button ${activeSection === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveSection('dashboard')}
            aria-current={activeSection === 'dashboard' ? 'page' : undefined}
          >
            Tracking Dashboard
          </button>
        </nav>
      </header>
      <main className="app-main">
        {renderSection()}
      </main>
      <footer className="app-footer">
        <p>&copy; 2025 Monstah Edge. All rights reserved.</p>
      </footer>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
} else {
  console.error('Root element not found');
}