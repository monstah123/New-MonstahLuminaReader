

export interface Flashcard {
  id: string;
  category: string;
  issue: string;
  solution: string;
}

export interface ProductStory {
  product: string;
  story: string;
}

// New interfaces for Personal Training content
export interface PTSalesFlashcard {
  id: string;
  category: string;
  issue: string;
  solution: string;
}

export interface PTButlerOpener {
  text: string;
  context: string;
}

export interface PTStory {
  title: string;
  story: string;
}

export const flashcards: Flashcard[] = [
  // PRICE OBJECTIONS
  {
    id: 'price-1',
    category: 'PRICE OBJECTIONS',
    issue: '“Too expensive.”',
    solution: '“Totally. Most people say that until they try it. Feel the grip/hoodie stretch for a sec.”',
  },
  {
    id: 'price-2',
    category: 'PRICE OBJECTIONS',
    issue: '“I can get cheaper online.”',
    solution: '“Facts — but cheaper gear fails fast. This is built for heavy lifters here.”',
  },
  {
    id: 'price-3',
    category: 'PRICE OBJECTIONS',
    issue: '“Not worth it.”',
    solution: '“Let me ask you: what would make it worth it for you personally?”',
  },
  {
    id: 'price-4',
    category: 'PRICE OBJECTIONS',
    issue: '“I’ll buy next time.”',
    solution: '“Cool — want me to save this exact one for you till later?”',
  },
  {
    id: 'price-5',
    category: 'PRICE OBJECTIONS',
    issue: '“I’m broke right now.”',
    solution: '“No worries. Here — try it anyway so you know which one you’ll get later.”',
  },

  // NEED OBJECTIONS
  {
    id: 'need-6',
    category: 'NEED OBJECTIONS',
    issue: '“I don’t need gloves/wraps.”',
    solution: '“Depends — what’s your main lift today?”',
  },
  {
    id: 'need-7',
    category: 'NEED OBJECTIONS',
    issue: '“I already have one.”',
    solution: '“Nice! What do you like about yours? What don’t you like?”',
  },
  {
    id: 'need-8',
    category: 'NEED OBJECTIONS',
    issue: '“I’m good.”',
    solution: '“Got you. Before I dip — feel this texture real quick.”',
  },
  {
    id: 'need-9',
    category: 'NEED OBJECTIONS',
    issue: '“I’m not into supplements.”',
    solution: '“Makes sense — do you ever feel low energy before training?”',
  },
  {
    id: 'need-10',
    category: 'NEED OBJECTIONS',
    issue: '“I don’t buy from people.”',
    solution: '“Respect. I test products with real lifters — feedback alone helps me.”',
  },

  // TRUST OBJECTIONS
  {
    id: 'trust-11',
    category: 'TRUST OBJECTIONS',
    issue: '“Is this legit?”',
    solution: '“I use it myself. And half the gym has tried this already.”',
  },
  {
    id: 'trust-12',
    category: 'TRUST OBJECTIONS',
    issue: '“Never heard of Monstah.”',
    solution: '“We’re a gym-born brand. Local. Built by lifters, for lifters.”',
  },
  {
    id: 'trust-13',
    category: 'TRUST OBJECTIONS',
    issue: '“Do you work here?”',
    solution: '“Not for the gym — I’m with the brand. I just test gear with real lifters.”',
  },

  // CONVENIENCE OBJECTIONS
  {
    id: 'convenience-14',
    category: 'CONVENIENCE OBJECTIONS',
    issue: '“I don’t want to carry it right now.”',
    solution: '“No stress — I can drop it in your locker.”',
  },
  {
    id: 'convenience-15',
    category: 'CONVENIENCE OBJECTIONS',
    issue: '“I’m mid-set.”',
    solution: '“All good, I’ll be quick — 10 seconds. Just check this.”',
  },

  // LOGICAL OBJECTIONS
  {
    id: 'logical-16',
    category: 'LOGICAL OBJECTIONS',
    issue: '“Not sure it works.”',
    solution: '“Try this movement with it right now — you’ll know instantly.”',
  },
  {
    id: 'logical-17',
    category: 'LOGICAL OBJECTIONS',
    issue: '“Are the results guaranteed?”',
    solution: '“Guaranteed performance upgrade for your session today.”',
  },
  {
    id: 'logical-18',
    category: 'LOGICAL OBJECTIONS',
    issue: '“Why yours and not brand X?”',
    solution: '“Try both side by side. You’ll feel the difference in 5 seconds.”',
  },

  // EMOTIONAL OBJECTIONS
  {
    id: 'emotional-19',
    category: 'EMOTIONAL OBJECTIONS',
    issue: '“Not my style.”',
    solution: '“Totally — what’s your style? I may have a better match.”',
  },
  {
    id: 'emotional-20',
    category: 'EMOTIONAL OBJECTIONS',
    issue: '“I don’t want to look like I’m trying hard.”',
    solution: '“Trust me — this makes you look like you lift serious, not try-hard.”',
  },

  // BONUS HIGH-LEVEL OBJECTIONS
  {
    id: 'bonus-21',
    category: 'BONUS HIGH-LEVEL OBJECTIONS',
    issue: '“Why should I trust you?”',
    solution: '“You shouldn’t — trust the product. Try it.”',
  },
  {
    id: 'bonus-22',
    category: 'BONUS HIGH-LEVEL OBJECTIONS',
    issue: '“I’ll think about it.”',
    solution: '“All good — quick question: what’s the part you’re unsure about?”',
  },
  {
    id: 'bonus-23',
    category: 'BONUS HIGH-LEVEL OBJECTIONS',
    issue: '“What if I don’t like it?”',
    solution: '“If you don’t love it today, I’ll swap you for another item.”',
  },
  {
    id: 'bonus-24',
    category: 'BONUS HIGH-LEVEL OBJECTIONS',
    issue: '“I Only buy online.”',
    solution: '“Same. But hands-on beats photos — check this real quick.”',
  },
  {
    id: 'bonus-25',
    category: 'BONUS HIGH-LEVEL OBJECTIONS',
    issue: '“Let me finish my workout first.”',
    solution: '“Absolutely — I’ll catch you after your last set.”',
  },
];

export const openerScripts: string[] = [
  '“Quick one — you use grips/wraps?”',
  '“Bro, feel this for 3 seconds.”',
  '“What’s your main lift today?”',
  '“Yo, random question — what gear do you wish worked better?”',
  '“You ever try Monstah stuff before?”',
  '“I’m testing some gear — want to be one of my testers?”',
  '“Real talk — what’s annoying you in your workouts lately?”',
  '“You look like you lift heavy — try this real quick.”',
  '“Do you train with wraps/gloves or raw?”',
  '“I only brought two today — want to feel one?”',
];

export const productStories: ProductStory[] = [
  {
    product: 'Preworkout – “The Monster Switch”',
    story: '“This preworkout is built for people who don’t want jittery caffeine — they want a switch. We made it because lifters here were tired of products that spike then crash. This blend gives clean strength, better pumps, and focus you actually feel under the bar. Most people hit their best sets on this.”',
  },
  {
    product: 'Hoodies – “Built for Lifting, Not Fashion”',
    story: '“These hoodies came from seeing people train in fashion hoodies that rip or get soaked. So we designed one that’s tough, stretchy, warm, and built for warm-ups and pump cover. Anyone who lifts heavy loves the feel — it’s made for the gym, not the mall.”',
  },
  {
    product: 'Gym Gloves – “Grip Without Sacrifice”',
    story: '“We built these because most gloves are either bulky or useless. These give real padding without killing your feel for the bar. People who hate calluses or grip slip instantly feel the difference.”',
  },
  {
    product: 'Wrist Wraps – “Protection for Your Future Self”',
    story: '“We saw lifters getting wrist pain way too early. So these wraps are designed to stabilize your joints on presses and overhead work. It’s not about today’s lift — it’s about being able to train next year without pain.”',
  },
  {
    product: 'Knee Wraps – “Confidence Under the Bar”',
    story: '“Knee pain kills progress. These wraps give bounce, support, and stability when you squat heavy. Lifters immediately feel more secure—like their knees are locked in.”',
  },
  {
    product: 'Nutritional Ebook – “Your Transformation Roadmap”',
    story: '“We built this ebook because people in the gym always ask the same questions: meals, macros, supplements, cutting, bulking. This is the exact system we give beginners and intermediates to make real progress. It’s like having a coach in your phone.”',
  },
  {
    product: 'Other Gym Gear – “Designed in a Gym, Tested in a Gym”',
    story: '“Everything we make is tested by lifters in real sessions — not in a studio. That’s why this gear performs better. Real lifters give us feedback, and we fix every detail till it’s perfect.”',
  },
];

// New data for Personal Training
export const ptSalesFlashcards: PTSalesFlashcard[] = [
  {
    id: 'pt-price-1',
    category: 'PRICE OBJECTIONS',
    issue: "“It's too expensive.”",
    solution: "“Think of it not as a cost, but as an investment in a guaranteed transformation. With 30+ years and 8 championships, I've already made every mistake so you don't have to. What's the cost of *not* getting results, year after year?”",
  },
  {
    id: 'pt-knowledge-2',
    category: 'KNOWLEDGE OBJECTIONS',
    issue: "“I know what I'm doing / I follow online programs.”",
    solution: "“You understand theory. I'll teach you mastery. Online programs are generic maps; I'm your GPS, guiding you step-by-step through the exact terrain I've conquered eight times. Are you seeing championship-level progress with your current approach?”",
  },
  {
    id: 'pt-time-3',
    category: 'TIME OBJECTIONS',
    issue: "“I don't have time for a trainer.”",
    solution: "“Actually, you don't have time to *waste*. My system is designed for maximum efficiency, to get you further faster. We'll identify and eliminate every wasted minute, every ineffective rep. Imagine the progress you could make if every single workout counted.”",
  },
  {
    id: 'pt-goals-4',
    category: 'GOALS OBJECTIONS',
    issue: "“I'm not looking to compete / just want to look good.”",
    solution: "“Looking good is a byproduct of elite training. My principles apply to anyone serious about maximizing their physique, whether for the stage or the beach. The difference? My clients actually *achieve* their ideal physique, not just dream about it.”",
  },
  {
    id: 'pt-preference-5',
    category: 'PREFERENCE OBJECTIONS',
    issue: "“I prefer to train alone.”",
    solution: "“Respect. But even champions have coaches. Training with me isn't about company; it's about external eyes, immediate correction, and pushing past limits you didn't know you had. The weights don't care about your feelings, but I care about your progress.”",
  },
];

export const ptButlerOpeners: PTButlerOpener[] = [
  { text: "“Yo bro/sis — honest question: you like lifting raw or with grip support?”", context: "Light, natural, gym-friendly." },
  { text: "“Check this out real quick — 3 seconds, I promise.”", context: "Great for handing gloves/wraps." },
  { text: "“You train heavy today? I got something that’ll boost it.”", context: "Strength identity." },
  { text: "“You ever tried Monstah gear? It’s built for people who actually lift.”", context: "Authority + tribal identity." },
  { text: "“Feel this fabric real fast — tell me this isn’t the cleanest hoodie.”", context: "Tactile + low pressure." },
  { text: "“What’s the one thing in your training you wish felt easier?”", context: "Need discovery disguised as conversation." },
  { text: "“You look strong — what gear do you trust right now?”", context: "Flattery + opens a gap." },
  { text: "“I’m testing this product with real lifters — wanna be one of the testers?”", context: "Instant engagement." },
  { text: "“Bro, quick one — what’s your weak link on heavy lifts?”", context: "Perfect for wraps, gloves, straps." },
  { text: "“I only brought a couple today — want to see what I got?”", context: "Curiosity + scarcity = 🔥 conversion." },
];

export const ptStories: PTStory[] = [
  {
    title: 'The Plateau Breaker: Why Settling Costs You More Than You Think',
    story: "For years, I saw lifters, dedicated just like you, hit the gym day in and day out, only to look the same. They'd read articles, watch videos, but never truly transform. Why? Because information without implementation by an expert is just noise. I spent 30+ years, pushing my body to its absolute limits, making mistakes, learning what *actually* builds a championship physique. My clients don't just 'train'; they break through what used to be their limits, realizing potential they never knew they had. The only real question is: are you ready to stop settling for 'good enough' and finally achieve what you're truly capable of?",
  },
  {
    title: 'The Blueprint for a Champion Body: Stop Guessing, Start Dominating',
    story: "Many think they can build a championship body by just 'working hard.' But without a precise blueprint, you're just building a house of cards. I've coached clients who spent years spinning their wheels, risking injury with flawed form, or following fad diets that derailed their progress. With my system, built from eight championship wins, every rep, every meal, every decision is optimized. It's the difference between guessing your way through a maze and having a master guide you directly to the finish line. Why gamble with your body and your time when a proven path to elite results exists?",
  },
  {
    title: "The True Cost of 'Free Advice': Your Potential Is Priceless",
    story: "The gym is full of advice – well-meaning, sometimes even harmful. People piece together programs from influencers, gym bros, and outdated articles, spending endless hours, only to look back after months or years with minimal change, or worse, an injury. I've seen it countless times. My clients come to me after wasting years, frustrated. What if I told you that in a fraction of that time, with the exact guidance that built 8 championship physiques, you could not only achieve your goals but surpass them? The real cost isn't hiring a champion; it's the cost of *not* training with one.",
  },
];

export const monstahBrandIdentityScript: string = `Monstah isn’t a fashion brand — it’s a gym-born brand. Everything we make starts here in real workouts, with real lifters. We design gear that solves problems you feel under the bar: weak grip, wrist pain, bad pump covers, low training energy.

Every hoodie, wrap, glove, and supplement we make is tested by lifters before it ever hits the website. Not made for influencers — made for people who lift heavy. That’s why Monstah gear feels different. It’s built in the gym, for the gym.`;

export const monstahKillerPitch: string = `“Look — Monstah gear is made for people who actually train, not for people taking mirror selfies. Everything in my bag today has been tested in real sessions by lifters here.

These wraps/gloves/hoodies/preworkout fix the exact problems lifters deal with: weak grip, wrist pain, bad pump covers, low energy.

Feel this. Notice how it fits your hand/wrist instantly? This is why lifters end up coming back for more. If it feels good now, imagine how it’ll feel under your next set`;


export const dashboardStructure = {
  salesActivityMetrics: [
    { label: 'People interacted with', type: 'number' },
    { label: 'Demos given', type: 'number' },
    { label: 'Sales attempts', type: 'number' },
    { label: 'Actual sales', type: 'number' },
    { label: 'Repeat customers', type: 'number' },
    { label: 'Bundles sold', type: 'number' },
  ],
  productPerformance: [
    { product: 'Preworkout' },
    { product: 'Hoodie' },
    { product: 'Gloves' },
    { product: 'Wrist Wraps' },
    { product: 'Knee Wraps' },
    { product: 'Ebook' },
    { product: 'Other Gear' },
  ],
  objectionsLog: 'Top 5 objections heard this week',
  scriptsEvolution: [
    { label: 'What lines worked best', type: 'textarea' },
    { label: 'What lines failed', type: 'textarea' },
    { label: 'New opener to test next week', type: 'textarea' },
  ],
  selfImprovementScores: [
    'Confidence',
    'Energy',
    'Product knowledge',
    'Objection handling',
    'Closing',
    'Consistency',
  ],
  weeklyWins: 'Top 3 wins',
  nextWeekGoals: 'Next Week Goals',
};