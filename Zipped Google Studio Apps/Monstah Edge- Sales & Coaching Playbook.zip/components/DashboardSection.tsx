
import React from 'react';
import { dashboardStructure } from '../data';

const DashboardSection: React.FC = () => {
  return (
    <section className="section-container" aria-labelledby="dashboard-section-title">
      <h2 id="dashboard-section-title" className="section-title">90-Day Tracking Dashboard</h2>
      <form className="dashboard-form">
        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Weekly Structure</legend>
          <div className="form-group">
            <label htmlFor="week-num">Week #:</label>
            <input type="number" id="week-num" name="week-num" />
          </div>
          <div className="form-group">
            <label htmlFor="dates">Dates:</label>
            <input type="text" id="dates" name="dates" placeholder="e.g., 2024-01-01 to 2024-01-07" />
          </div>
        </fieldset>

        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Sales Activity Metrics</legend>
          {dashboardStructure.salesActivityMetrics.map((metric, index) => (
            <div className="form-group" key={index}>
              <label htmlFor={`sales-metric-${index}`}>{metric.label}:</label>
              <input type={metric.type} id={`sales-metric-${index}`} name={`sales-metric-${index}`} />
            </div>
          ))}
        </fieldset>

        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Product Performance</legend>
          <div className="table-responsive">
            <table className="product-performance-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Demos</th>
                  <th>Sales</th>
                  <th>Conversion %</th>
                  <th>Notes</th>
                </tr>
              </thead>
              <tbody>
                {dashboardStructure.productPerformance.map((product, index) => (
                  <tr key={index}>
                    <td>{product.product}</td>
                    <td><input type="number" aria-label={`${product.product} Demos`} /></td>
                    <td><input type="number" aria-label={`${product.product} Sales`} /></td>
                    <td><input type="text" aria-label={`${product.product} Conversion %`} /></td>
                    <td><input type="text" aria-label={`${product.product} Notes`} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </fieldset>

        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Objections Log</legend>
          <div className="form-group">
            <label htmlFor="objections-log">{dashboardStructure.objectionsLog}:</label>
            <textarea id="objections-log" name="objections-log" rows={4}></textarea>
          </div>
        </fieldset>

        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Scripts Evolution</legend>
          {dashboardStructure.scriptsEvolution.map((script, index) => (
            <div className="form-group" key={index}>
              <label htmlFor={`script-evolution-${index}`}>{script.label}:</label>
              <textarea id={`script-evolution-${index}`} name={`script-evolution-${index}`} rows={3}></textarea>
            </div>
          ))}
        </fieldset>

        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Self-Improvement Scores (1–10)</legend>
          <div className="scores-grid">
            {dashboardStructure.selfImprovementScores.map((scoreLabel, index) => (
              <div className="form-group score-item" key={index}>
                <label htmlFor={`score-${index}`}>{scoreLabel}:</label>
                <input
                  type="range"
                  id={`score-${index}`}
                  name={`score-${index}`}
                  min="1"
                  max="10"
                  defaultValue="5"
                  list="tickmarks"
                />
                <datalist id="tickmarks">
                  <option value="1" label="1"></option>
                  <option value="2"></option>
                  <option value="3"></option>
                  <option value="4"></option>
                  <option value="5" label="5"></option>
                  <option value="6"></option>
                  <option value="7"></option>
                  <option value="8"></option>
                  <option value="9"></option>
                  <option value="10" label="10"></option>
                </datalist>
                <span className="range-value" aria-hidden="true">{/* Displays current value of slider */}</span>
              </div>
            ))}
          </div>
        </fieldset>

        <fieldset className="dashboard-fieldset">
          <legend className="dashboard-legend">Weekly Wins & Goals</legend>
          <div className="form-group">
            <label htmlFor="weekly-wins">{dashboardStructure.weeklyWins}:</label>
            <textarea id="weekly-wins" name="weekly-wins" rows={4}></textarea>
          </div>
          <div className="form-group">
            <label htmlFor="next-week-goals">{dashboardStructure.nextWeekGoals}:</label>
            <textarea id="next-week-goals" name="next-week-goals" rows={4}></textarea>
          </div>
        </fieldset>

        <button type="submit" className="submit-button" disabled>Save Dashboard (Not implemented in this version)</button>
      </form>
    </section>
  );
};

export default DashboardSection;
