import React, { useState, useMemo, useEffect } from 'react';
import Flashcard from './Flashcard';
import { ptSalesFlashcards, ptButlerOpeners, ptStories, monstahBrandIdentityScript, monstahKillerPitch } from '../data';
import AIChatComponent from './AIChatComponent'; // New import

type PTSection = 'pt-flashcards' | 'pt-openers' | 'pt-stories' | 'pt-brand-script' | 'pt-killer-pitch' | 'pt-ai-coach'; // Updated type

const PersonalTrainingSection: React.FC = () => {
  const [activePTSection, setActivePTSection] = useState<PTSection>('pt-flashcards');

  const categories = useMemo(() => {
    const uniqueCategories = new Set<string>();
    ptSalesFlashcards.forEach((card) => uniqueCategories.add(card.category));
    return Array.from(uniqueCategories);
  }, []);

  const [selectedCategory, setSelectedCategory] = useState<string>(categories[0] || '');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);

  const filteredFlashcards = useMemo(() => {
    return ptSalesFlashcards.filter((card) => card.category === selectedCategory);
  }, [selectedCategory]);

  useEffect(() => {
    setCurrentCardIndex(0); // Reset index when category changes
  }, [selectedCategory]);

  const handleNext = () => {
    setCurrentCardIndex((prevIndex) => (prevIndex + 1) % filteredFlashcards.length);
  };

  const handlePrevious = () => {
    setCurrentCardIndex((prevIndex) =>
      prevIndex === 0 ? filteredFlashcards.length - 1 : prevIndex - 1,
    );
  };

  const renderPTContent = () => {
    switch (activePTSection) {
      case 'pt-flashcards':
        if (!filteredFlashcards.length) {
          return <div className="section-container">No flashcards available for this category.</div>;
        }
        const currentFlashcard = filteredFlashcards[currentCardIndex];
        return (
          <>
            <div className="category-selector">
              <label htmlFor="pt-category-select" className="sr-only">Select Category:</label>
              <select
                id="pt-category-select"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                aria-controls="pt-flashcard-display"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
            <div id="pt-flashcard-display" className="flashcard-display-area">
              <Flashcard issue={currentFlashcard.issue} solution={currentFlashcard.solution} />
              <div className="flashcard-navigation">
                <button
                  onClick={handlePrevious}
                  className="nav-button"
                  aria-label="Previous personal training flashcard"
                >
                  Previous
                </button>
                <span className="card-counter" aria-live="polite">
                  {currentCardIndex + 1} / {filteredFlashcards.length}
                </span>
                <button
                  onClick={handleNext}
                  className="nav-button"
                  aria-label="Next personal training flashcard"
                >
                  Next
                </button>
              </div>
            </div>
          </>
        );
      case 'pt-openers':
        return (
          <div className="openers-list-container">
            <h3 className="section-subtitle">TEN OPENERS CUSTOMIZED FOR YOUR PERSONALITY</h3>
            <ol className="openers-list">
              {ptButlerOpeners.map((opener, index) => (
                <li key={index} className="opener-item">
                  <span className="opener-text">{opener.text}</span>
                  <p className="opener-context">{opener.context}</p>
                </li>
              ))}
            </ol>
          </div>
        );
      case 'pt-stories':
        return (
          <div className="product-stories-list">
            {ptStories.map((item, index) => (
              <details key={index} className="product-story-details">
                <summary className="product-story-summary">
                  {item.title}
                </summary>
                <p className="product-story-text">{item.story}</p>
              </details>
            ))}
          </div>
        );
      case 'pt-brand-script':
        return (
          <div className="static-content-display">
            <h3 className="section-subtitle">THE MONSTAH BRAND IDENTITY SCRIPT (“Gym-Born. Gym-Proof.”)</h3>
            <p className="static-script-text">{monstahBrandIdentityScript}</p>
          </div>
        );
      case 'pt-killer-pitch':
        return (
          <div className="static-content-display">
            <h3 className="section-subtitle">YOUR 30-SECOND KILLER PITCH (GYM-TESTED)</h3>
            <p className="static-script-text">{monstahKillerPitch}</p>
          </div>
        );
      case 'pt-ai-coach':
        return <AIChatComponent />;
      default:
        return null;
    }
  };

  return (
    <section className="section-container" aria-labelledby="pt-section-title">
      <h2 id="pt-section-title" className="section-title">Personal Training Sales Playbook</h2>
      <nav className="sub-nav" aria-label="Personal Training Sections">
        <button
          className={`nav-button ${activePTSection === 'pt-flashcards' ? 'active' : ''}`}
          onClick={() => setActivePTSection('pt-flashcards')}
          aria-current={activePTSection === 'pt-flashcards' ? 'page' : undefined}
        >
          PT Objections
        </button>
        <button
          className={`nav-button ${activePTSection === 'pt-openers' ? 'active' : ''}`}
          onClick={() => setActivePTSection('pt-openers')}
          aria-current={activePTSection === 'pt-openers' ? 'page' : undefined}
        >
          PT Openers
        </button>
        <button
          className={`nav-button ${activePTSection === 'pt-stories' ? 'active' : ''}`}
          onClick={() => setActivePTSection('pt-stories')}
          aria-current={activePTSection === 'pt-stories' ? 'page' : undefined}
        >
          PT Storytelling
        </button>
        <button
          className={`nav-button ${activePTSection === 'pt-brand-script' ? 'active' : ''}`}
          onClick={() => setActivePTSection('pt-brand-script')}
          aria-current={activePTSection === 'pt-brand-script' ? 'page' : undefined}
        >
          Brand Script
        </button>
        <button
          className={`nav-button ${activePTSection === 'pt-killer-pitch' ? 'active' : ''}`}
          onClick={() => setActivePTSection('pt-killer-pitch')}
          aria-current={activePTSection === 'pt-killer-pitch' ? 'page' : undefined}
        >
          Killer Pitch
        </button>
        <button
          className={`nav-button ${activePTSection === 'pt-ai-coach' ? 'active' : ''}`}
          onClick={() => setActivePTSection('pt-ai-coach')}
          aria-current={activePTSection === 'pt-ai-coach' ? 'page' : undefined}
        >
          AI Pitch Coach
        </button>
      </nav>
      <div className="pt-content-area">
        {renderPTContent()}
      </div>
    </section>
  );
};

export default PersonalTrainingSection;