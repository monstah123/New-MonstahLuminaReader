import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";

// System instructions for different modes, keyed by the command suffix (e.g., "easy mode")
const modeSystemInstructions: Record<string, string> = {
  'start': "You are a real-time gym customer. Respond naturally, as if in a gym environment. You are about to be pitched a product. Your initial response should be neutral or slightly curious, encouraging the salesperson to start their pitch. Acknowledge that you are ready for the pitch.",
  'easy mode': "You are a real-time gym customer. You are generally receptive and open to new products, but not a pushover. Ask a few clarifying questions and express mild interest. Make it easy for the salesperson to sell to you.",
  'medium mode': "You are a real-time gym customer. You ask questions, express some mild resistance, and are somewhat skeptical. You are not easily convinced but can be swayed with good arguments. You are looking for value.",
  'hard mode': "You are a real-time gym customer. You are very skeptical and have strong price objections. You will challenge the salesperson and are difficult to convince. You might mention competitors or cheaper alternatives.",
  'savage mode': "You are a real-time gym customer. You are unpredictable, rude, difficult, and dismissive. You don't want to be bothered and will react negatively to pitches. You are the ultimate challenge for a salesperson.",
  '30 second challenge': "You are a real-time gym customer. The salesperson has only 30 seconds to deliver their pitch. Your responses should reflect a limited attention span. If the pitch exceeds 30 seconds (simulated by length of user input or multiple turns), you will cut them off. After their initial 30s pitch, ask one quick follow-up question, then express a quick decision.",
  'throw objections': "You are a real-time gym customer. Your primary goal is to throw common objections at the salesperson. Focus heavily on price, need, trust, and logical objections. You will continuously raise new objections even after one is handled.",
  'simulate gym floor': "You are a real-time gym customer. Simulate a realistic gym floor scenario. You are busy with your workout, possibly wearing headphones, or in the middle of a set. Your initial responses should reflect being interrupted or preoccupied, then slowly become more engaged if the pitch is good. Mention typical gym distractions.",
};

interface Message {
  role: 'user' | 'model' | 'system';
  text: string;
}

const AIChatComponent: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>('');
  const [currentMode, setCurrentMode] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const chatRef = useRef<Chat | null>(null);
  const aiRef = useRef<GoogleGenAI | null>(null); // Use a ref for GoogleGenAI instance

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // Initialize GoogleGenAI once when component mounts
    aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const initializeChatSession = async (modeKey: string) => {
    if (!aiRef.current) {
      setMessages((prev) => [...prev, { role: 'system', text: 'Error: AI client not initialized.' }]);
      return;
    }

    const systemInstruction = modeSystemInstructions[modeKey];
    if (!systemInstruction) {
      console.error("Invalid mode key:", modeKey);
      setMessages((prev) => [...prev, { role: 'system', text: `Error: Unknown mode "${modeKey}".` }]);
      return;
    }

    // Clear previous chat history and start a new one
    setMessages([{ role: 'system', text: `AI Pitch Coach: Mode set to "${modeKey}".` }]);
    setCurrentMode(modeKey);

    chatRef.current = aiRef.current.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: systemInstruction,
      },
    });

    // Send a welcoming message from the AI in the new mode
    setIsLoading(true);
    try {
      const response = await chatRef.current.sendMessageStream({ message: "Hello! I am ready for your pitch. Please begin." });
      let fullText = "";
      for await (const chunk of response) {
        fullText += chunk.text;
      }
      setMessages((prev) => [...prev, { role: 'model', text: fullText }]);
    } catch (error) {
      console.error('Error initializing AI chat:', error);
      setMessages((prev) => [...prev, { role: 'system', text: 'Error initializing AI coach. Please try again.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (input.trim() === '' || isLoading) return;

    const userMessage = input;
    setMessages((prev) => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setIsLoading(true);

    const commandPrefix = "pitch coach:";
    if (userMessage.toLowerCase().startsWith(commandPrefix)) {
      const commandSuffix = userMessage.toLowerCase().substring(commandPrefix.length).trim();
      if (modeSystemInstructions[commandSuffix]) {
        await initializeChatSession(commandSuffix);
        return; // Mode command handled, no further AI message for this input
      } else if (commandSuffix === 'start') {
        await initializeChatSession('start');
        return;
      } else {
        setMessages((prev) => [...prev, { role: 'model', text: `Unknown command: "Pitch Coach: ${commandSuffix}". Please use one of the specified modes.` }]);
        setIsLoading(false);
        return;
      }
    }

    // If no chat session is active, or if it's not a mode command
    if (!chatRef.current || !currentMode) {
      setMessages((prev) => [
        ...prev,
        { role: 'model', text: "Please start a Pitch Coach session by typing 'Pitch Coach: start' or click a mode button." },
      ]);
      setIsLoading(false);
      return;
    }

    try {
      const response = await chatRef.current.sendMessageStream({ message: userMessage });
      let fullText = "";
      for await (const chunk of response) {
        fullText += chunk.text;
      }
      setMessages((prev) => [...prev, { role: 'model', text: fullText }]);
    } catch (error) {
      console.error('Error sending message to AI chat:', error);
      // Implement specific error handling as per guidelines
      if (error instanceof Error && error.message.includes("Requested entity was not found.")) {
        setMessages((prev) => [...prev, { role: 'system', text: 'API Key issue detected. Please ensure your API key is correctly configured and has access to the Gemini API. You may need to refresh the page or select a key if prompted.' }]);
      } else {
        setMessages((prev) => [...prev, { role: 'system', text: 'An error occurred while getting a response. Please try again or restart the session.' }]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="ai-coach-container section-container">
      <h2 className="section-title">Your AI-Powered Pitch Coach</h2>
      <p className="coach-intro">
        Use this script in conversation with me anytime. Just type: "Pitch Coach: start" and I'll become your real-time gym customer.
        You can also choose a mode:
      </p>
      <div className="mode-buttons">
        {Object.keys(modeSystemInstructions).filter(modeKey => modeKey !== 'start').map((modeKey) => (
          <button
            key={modeKey}
            className={`mode-button ${currentMode === modeKey ? 'active' : ''}`}
            onClick={() => initializeChatSession(modeKey)}
            disabled={isLoading}
            aria-label={`Start ${modeKey} session`}
          >
            {modeKey.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
          </button>
        ))}
        <button
            className={`mode-button ${currentMode === 'start' ? 'active' : ''}`}
            onClick={() => initializeChatSession('start')}
            disabled={isLoading}
            aria-label="Start basic pitch coach session"
          >
            Start Basic Session
          </button>
      </div>
      <div className="chat-window" role="log" aria-live="polite">
        {messages.map((msg, index) => (
          <div key={index} className={`chat-message ${msg.role}`}>
            <span className="chat-role">
              {msg.role === 'user' ? 'You:' : msg.role === 'model' ? 'Coach:' : 'System:'}
            </span>
            <p>{msg.text}</p>
          </div>
        ))}
        {isLoading && (
          <div className="chat-message model loading">
            <span className="chat-role">Coach: </span>
            <p>Thinking...</p>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="chat-input-area">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSendMessage();
            }
          }}
          placeholder={currentMode ? `Pitch for the "${currentMode}" mode...` : 'Type "Pitch Coach: start" or click a mode button to begin...'}
          disabled={isLoading}
          aria-label="Your pitch or command"
          rows={3}
        />
        <button onClick={handleSendMessage} disabled={isLoading} className="send-button" aria-label="Send message">
          {isLoading ? 'Sending...' : 'Send'}
        </button>
      </div>
    </div>
  );
};

export default AIChatComponent;