
import React, { useState, useRef, useEffect } from 'react';

interface FlashcardProps {
  issue: string;
  solution: string;
}

// Fix: Declaring webkitSpeechRecognition and SpeechRecognition as `any`
// within the global Window interface to resolve "Cannot find name 'SpeechRecognition'"
// and "Cannot find namespace 'window'".
// This is a workaround if the 'dom' library types are not configured in tsconfig.json.
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

const Flashcard: React.FC<FlashcardProps> = ({ issue, solution }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  // Fix: Use InstanceType<typeof window.SpeechRecognition> to correctly type the useRef hook
  // for the SpeechRecognition instance, relying on the 'any' declaration in global Window interface.
  const recognitionRef = useRef<InstanceType<typeof window.SpeechRecognition> | null>(null);

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech Recognition is not supported by this browser. Please use Chrome or a compatible browser for this feature.');
      return;
    }

    // Stop any existing recognition instance before starting a new one
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      setTranscript(''); // Clear previous transcript
      console.log('Speech recognition started');
    };

    recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setTranscript(finalTranscript + interimTranscript);
    };

    recognition.onerror = (event: any) => { // Cast event to any if SpeechRecognitionErrorEvent is not available
      console.error('Speech recognition error', event);
      setIsListening(false);
      recognitionRef.current = null;
      alert(`Speech recognition error: ${event.error}. Please ensure microphone access is granted.`);
    };

    recognition.onend = () => {
      console.log('Speech recognition ended');
      setIsListening(false);
      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      console.log('Speech recognition stopped');
    }
    setIsListening(false);
  };

  const handleFlip = () => {
    if (isFlipped) {
      // If flipping back to front, stop listening
      stopListening();
    }
    setIsFlipped(!isFlipped);
  };

  useEffect(() => {
    // Cleanup on component unmount
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  return (
    <div className="flashcard" aria-live="polite">
      <div className="flashcard-content">
        {isFlipped ? (
          <div className="flashcard-back">
            <p className="flashcard-label-solution">✔ Solution:</p>
            <p className="flashcard-text" aria-atomic="true">{solution}</p>
            <div className="practice-area">
              <h3>Practice Your Response:</h3>
              <div className="practice-buttons">
                {!isListening ? (
                  <button
                    onClick={startListening}
                    className="flashcard-practice-button start"
                    aria-label="Start practicing with speech recognition"
                  >
                    Start Practice
                  </button>
                ) : (
                  <button
                    onClick={stopListening}
                    className="flashcard-practice-button stop"
                    aria-label="Stop speech recognition"
                  >
                    Stop Practice
                  </button>
                )}
              </div>
              {isListening && <p className="listening-indicator">Listening...</p>}
              {transcript && (
                <div className="transcript-display" aria-live="polite" aria-atomic="true">
                  <h4>Your Transcription:</h4>
                  <p>{transcript}</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flashcard-front">
            <p className="flashcard-label-issue">❌ Objection:</p>
            <p className="flashcard-text" aria-atomic="true">{issue}</p>
          </div>
        )}
      </div>
      <button
        onClick={handleFlip}
        className="flashcard-flip-button"
        aria-expanded={isFlipped}
        aria-label={isFlipped ? 'Hide solution and practice area' : 'Reveal solution and practice area'}
      >
        {isFlipped ? 'Hide Answer' : 'Reveal Answer'}
      </button>
    </div>
  );
};

export default Flashcard;
