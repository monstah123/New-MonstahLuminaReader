
import React, { useState, useEffect, useLayoutEffect } from 'react';
import ReactDOM from 'react-dom/client';
import FlashcardSection from './components/FlashcardSection';
import OpenersSection from './components/OpenersSection';
import StoriesSection from './components/StoriesSection';
import DashboardSection from './components/DashboardSection';
import PersonalTrainingSection from './components/PersonalTrainingSection';

type Section = 'flashcards' | 'openers' | 'stories' | 'dashboard' | 'personal-training';

interface IconProps {
  className?: string;
  onClick?: () => void;
}

const SunIcon = ({ className, onClick }: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    onClick={onClick}
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="5"></circle>
    <line x1="12" y1="1" x2="12" y2="3"></line>
    <line x1="12" y1="21" x2="12" y2="23"></line>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
    <line x1="1" y1="12" x2="3" y2="12"></line>
    <line x1="21" y1="12" x2="23" y2="12"></line>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
  </svg>
);

const MoonIcon = ({ className, onClick }: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    onClick={onClick}
    aria-hidden="true"
  >
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
  </svg>
);

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>('flashcards');
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  // Hardcoded Critical Styles to override environment defaults
  const criticalStyles = `
    /* Force root accent color to GRAY/WHITE (Controls selection handles on mobile) */
    :root, html, body {
      accent-color: #e0e0e0 !important;
      caret-color: #e0e0e0 !important;
    }

    html, body, #root {
      background-color: #121212 !important;
      color: #e0e0e0 !important;
      min-height: 100vh;
    }
    
    /* Force Orange Headers (Brand Identity) */
    h1, h2, h3, h4, .app-title, .section-title {
      color: #ff5252 !important;
      font-family: 'Roboto', sans-serif;
    }

    /* Force Active Button Color */
    .nav-button.active {
      background-color: #ff5252 !important;
      color: white !important;
      border-color: #ff5252 !important;
    }

    /* Force Light Theme overrides if class is present */
    body.light-theme, body.light-theme #root {
      background-color: #f5f7fa !important;
      color: #333333 !important;
    }
    
    body.light-theme h1, 
    body.light-theme h2, 
    body.light-theme .app-title, 
    body.light-theme .section-title {
      color: #d32f2f !important;
    }

    /* Links: White Text on Gray Background (Pill Style) */
    a {
      color: #ffffff !important;
      background-color: #424242;
      padding: 2px 6px;
      border-radius: 4px;
      text-decoration: none;
    }
    a:hover {
      background-color: #616161;
    }

    /* Global Selection Color: White text on Gray background */
    ::selection {
      background-color: #757575 !important;
      color: #ffffff !important;
      text-shadow: none !important;
    }
    ::-moz-selection {
      background-color: #757575 !important;
      color: #ffffff !important;
      text-shadow: none !important;
    }

    /* 
      FORCE INPUT COLORS 
      -webkit-text-fill-color is crucial for iOS Safari
    */
    input, textarea, select, [contenteditable] {
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
      caret-color: #ffffff !important;
      background-color: #2c2c2c !important;
    }

    /* Light mode input overrides */
    body.light-theme input, 
    body.light-theme textarea,
    body.light-theme select {
      color: #333333 !important;
      -webkit-text-fill-color: #333333 !important;
      caret-color: #333333 !important;
      background-color: #ffffff !important;
    }

    /* Remove Blue Focus Outlines -> Now Gray/White */
    input:focus, textarea:focus, select:focus, button:focus {
      outline: 2px solid #bdbdbd !important;
      outline-offset: 1px;
    }
    
    /* Specific overrides for Chat Bubbles to ensure no Blue leaks */
    .chat-message.user p {
        background-color: #424242 !important;
        color: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
    }
  `;

  const handleThemeChange = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    
    if (newTheme === 'light') {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
    
    try {
      localStorage.setItem('theme', newTheme);
    } catch (e) {
      // Ignore localStorage errors
    }
  };

  useLayoutEffect(() => {
    // Force initial styles
    document.body.style.backgroundColor = '#121212';
    document.body.style.color = '#e0e0e0';
    
    const getInitialTheme = (): 'light' | 'dark' => {
      try {
        const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
        if (savedTheme) return savedTheme;
      } catch (e) {
        // ignore
      }
      return 'dark'; 
    };

    const initialTheme = getInitialTheme();
    handleThemeChange(initialTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    handleThemeChange(newTheme);
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'flashcards':
        return <FlashcardSection />;
      case 'openers':
        return <OpenersSection />;
      case 'stories':
        return <StoriesSection />;
      case 'dashboard':
        return <DashboardSection />;
      case 'personal-training':
        return <PersonalTrainingSection />;
      default:
        return <FlashcardSection />;
    }
  };

  return (
    <div 
      className={`app-container ${theme === 'light' ? 'light-theme' : ''}`}
    >
      {/* Inject Critical Styles directly into DOM using dangerouslySetInnerHTML to prevent escaping */}
      <style dangerouslySetInnerHTML={{ __html: criticalStyles }} />
      
      <header className="app-header">
        <div className="header-top">
          <h1 className="app-title">Monstah Edge: Sales & Coaching Playbook</h1>
          <div className="theme-toggle-wrapper">
            <SunIcon 
              className={`theme-icon sun ${theme === 'light' ? 'active' : ''}`} 
              onClick={() => handleThemeChange('light')}
            />
            <label className="theme-switch" aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}>
              <input 
                type="checkbox" 
                checked={theme === 'dark'} 
                onChange={toggleTheme} 
              />
              <span className="slider round"></span>
            </label>
            <MoonIcon 
              className={`theme-icon moon ${theme === 'dark' ? 'active' : ''}`} 
              onClick={() => handleThemeChange('dark')}
            />
          </div>
        </div>
        <nav className="main-nav" aria-label="Main Navigation">
          <button
            className={`nav-button ${activeSection === 'flashcards' ? 'active' : ''}`}
            onClick={() => setActiveSection('flashcards')}
            aria-current={activeSection === 'flashcards' ? 'page' : undefined}
          >
            Objections Flashcards
          </button>
          <button
            className={`nav-button ${activeSection === 'openers' ? 'active' : ''}`}
            onClick={() => setActiveSection('openers')}
            aria-current={activeSection === 'openers' ? 'page' : undefined}
          >
            Openers
          </button>
          <button
            className={`nav-button ${activeSection === 'stories' ? 'active' : ''}`}
            onClick={() => setActiveSection('stories')}
            aria-current={activeSection === 'stories' ? 'page' : undefined}
          >
            Product Storytelling
          </button>
          <button
            className={`nav-button ${activeSection === 'personal-training' ? 'active' : ''}`}
            onClick={() => setActiveSection('personal-training')}
            aria-current={activeSection === 'personal-training' ? 'page' : undefined}
          >
            Personal Training
          </button>
          <button
            className={`nav-button ${activeSection === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveSection('dashboard')}
            aria-current={activeSection === 'dashboard' ? 'page' : undefined}
          >
            Tracking Dashboard
          </button>
        </nav>
      </header>
      <main className="app-main">
        {renderSection()}
      </main>
      <footer className="app-footer">
        <p>&copy; 2025 Monstah Edge. All rights reserved.</p>
      </footer>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
} else {
  console.error('Root element not found');
}
