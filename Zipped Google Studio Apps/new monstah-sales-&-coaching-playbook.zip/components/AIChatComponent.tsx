
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";

// System instructions for different modes, keyed by the command suffix (e.g., "easy mode")
const modeSystemInstructions: Record<string, string> = {
  'start': "You are a potential customer on the gym floor. You are neutral and waiting for the salesperson to initiate a conversation. React naturally to their opener.",
  'easy mode': "Roleplay as 'Alex', a friendly gym newcomer. You are enthusiastic and looking for guidance. You've heard of the Monstah brand and are eager to try it. Ask one or two simple questions (e.g., 'Is it comfortable?', 'How much is it?') and then agree to buy enthusiastically. Your goal is to help the salesperson feel a win.",
  'medium mode': "Roleplay as 'Jordan', an experienced lifter. You are pragmatic. You have your routine and your gear, so you need a logical reason to switch. Ask about durability, material quality, or specific performance benefits. You can be convinced, but the salesperson must explain 'why' it's better than what you have.",
  'hard mode': "Roleplay as 'Casey', a cynical veteran powerlifter. You've seen every gimmick come and go. You believe most supplements are snake oil and most gear is overpriced fashion. Object to the price ('$60 for a hoodie? Crazy.'), the necessity ('I lift raw'), and the brand ('Never heard of you'). The salesperson must use strong social proof and performance guarantees to win you over.",
  'savage mode': "Roleplay as a gym-goer who is having a bad day and hates interruptions. You are wearing headphones. If the salesperson approaches, be dismissive: 'Can't you see I'm busy?', 'Not interested', 'Get lost'. The salesperson must be extremely respectful, brief, and thick-skinned to turn this around. Do not make it easy.",
  '30 second challenge': "Roleplay as a busy executive on a 30-minute lunch break workout. You are rushing. You will only listen if the pitch is immediate and high-value. If the salesperson introduces themselves slowly or asks 'How are you?', cut them off: 'I'm in a rush, what is it?'. If they don't hook you in 3 sentences, end the conversation. If they are concise, buy immediately.",
  'throw objections': "Roleplay as a customer who loves to debate. Your goal is to test the salesperson's objection handling skills. Rapid-fire objections: 'Too expensive', 'Wrong color', 'I heard bad reviews', 'I don't need it', 'My wife won't let me'. Do not let them close until they have successfully isolated and overcome at least three distinct objections.",
  'simulate gym floor': "Roleplay a realistic ambient scenario. You are distracted. Maybe you are counting reps, or texting. The salesperson needs to get your attention ('Excuse me?', 'Huh? Oh, hi.'). Be somewhat absent-minded initially. If they ask a good engaging question, snap out of it and engage. If they sound like a robot, ignore them.",
};

const modeExamples: Record<string, string> = {
  'start': "Try: 'Hey! Quick question - do you prefer lifting raw or with wraps?'",
  'easy mode': "Try: 'Hey! I noticed you're new here. Have you seen the new Monstah grip gloves? They make holding the bar way easier.'",
  'medium mode': "Try: 'I see you're using standard cotton straps. These Monstah ones have a rubberized weave so the bar literally cannot slip. Want to feel the grip?'",
  'hard mode': "Try: 'Look, I know you've been lifting for years and probably think gloves are for beginners. But these are for callus prevention so you can train heavier, more often. Just feel the padding.'",
  'savage mode': "Try: 'I can see you're in the zone, I won't kill your flow. Just wanted to drop this free sample of our pre-workout for your next set. Peace.'",
  '30 second challenge': "Try: 'Wrist pain on that press? These wraps fix it instantly. Try them for one set, on me.'",
  'throw objections': "Try: 'This hoodie is built for lifting. It stretches so it won't rip when you bench, unlike that cotton one.'",
  'simulate gym floor': "Try: 'Yo! Quick question before your next set... what do you think of this belt?'",
};

interface Message {
  role: 'user' | 'model' | 'system';
  text: string;
}

const AIChatComponent: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>('');
  const [currentMode, setCurrentMode] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [apiKeySelected, setApiKeySelected] = useState<boolean>(false);
  const chatRef = useRef<Chat | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    const checkKeyStatus = async () => {
      if (typeof window.aistudio !== 'undefined' && typeof window.aistudio.hasSelectedApiKey === 'function') {
        try {
          const hasKey = await window.aistudio.hasSelectedApiKey();
          setApiKeySelected(hasKey);
        } catch (error) {
          console.error("Error checking API key status:", error);
          setMessages((prev) => [...prev, { role: 'system', text: 'Error checking API key status.' }]);
          setApiKeySelected(false);
        }
      } else {
        // Assume API_KEY is handled externally or present for local dev without aistudio
        console.warn("window.aistudio not found. Assuming API_KEY is available.");
        setApiKeySelected(true);
      }
    };
    checkKeyStatus();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getGoogleGenAIInstance = (): GoogleGenAI => {
    // API_KEY is guaranteed to be available via process.env.API_KEY after user selection
    // and platform injection.
    if (!process.env.API_KEY) {
      console.error("API_KEY is not defined. Cannot initialize GoogleGenAI.");
      throw new Error("API_KEY_UNDEFINED");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  };

  const handleSelectApiKey = async () => {
    if (typeof window.aistudio !== 'undefined' && typeof window.aistudio.openSelectKey === 'function') {
      try {
        await window.aistudio.openSelectKey();
        // Assume success after openSelectKey to mitigate race condition
        setApiKeySelected(true);
        // Clear previous session/messages as a new key might imply a fresh start
        setMessages([]);
        setCurrentMode(null);
      } catch (error) {
        console.error("Failed to open API key selection:", error);
        setMessages((prev) => [...prev, { role: 'system', text: 'Failed to open API key selection dialog.' }]);
        setApiKeySelected(false); // Stay in unselected state
      }
    } else {
      setMessages((prev) => [...prev, { role: 'system', text: 'API key selection not available in this environment.' }]);
    }
  };

  const initializeChatSession = async (modeKey: string) => {
    if (!apiKeySelected) {
      setMessages((prev) => [...prev, { role: 'system', text: 'Please select an API key first.' }]);
      return;
    }
    setIsLoading(true);

    try {
      const ai = getGoogleGenAIInstance(); // Create a new instance for the session
      const systemInstruction = modeSystemInstructions[modeKey];
      if (!systemInstruction) {
        console.error("Invalid mode key:", modeKey);
        setMessages((prev) => [...prev, { role: 'system', text: `Error: Unknown mode "${modeKey}".` }]);
        setIsLoading(false);
        return;
      }

      // Clear previous chat history and start a new one
      setMessages([{ role: 'system', text: `AI Pitch Coach: Mode set to "${modeKey.toUpperCase()}".` }]);
      setCurrentMode(modeKey);

      chatRef.current = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: systemInstruction,
        },
      });

      // Send a welcoming message from the AI in the new mode
      const response = await chatRef.current.sendMessageStream({ message: "Hello! I am ready for your pitch. Please begin." });
      let fullText = "";
      for await (const chunk of response) {
        fullText += chunk.text;
      }
      setMessages((prev) => [...prev, { role: 'model', text: fullText }]);
    } catch (error: any) {
      console.error('Error initializing AI chat:', error);
      if (error.message === "API_KEY_UNDEFINED") {
        setMessages((prev) => [...prev, { role: 'system', text: 'API Key is missing. Please select your API key.' }]);
        setApiKeySelected(false);
      } else if (error.message.includes("Requested entity was not found.")) {
        setMessages((prev) => [...prev, { role: 'system', text: 'API Key issue detected. Please re-select your API key.' }]);
        setApiKeySelected(false);
      } else {
        setMessages((prev) => [...prev, { role: 'system', text: 'An error occurred while initializing the AI coach. Please try again.' }]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (input.trim() === '' || isLoading) return;

    if (!apiKeySelected) {
      setMessages((prev) => [...prev, { role: 'system', text: 'Please select an API key first to send messages.' }]);
      return;
    }

    const userMessage = input;
    setMessages((prev) => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setIsLoading(true);

    const commandPrefix = "pitch coach:";
    if (userMessage.toLowerCase().startsWith(commandPrefix)) {
      const commandSuffix = userMessage.toLowerCase().substring(commandPrefix.length).trim();
      if (modeSystemInstructions[commandSuffix]) {
        await initializeChatSession(commandSuffix);
        return; // Mode command handled, no further AI message for this input
      } else if (commandSuffix === 'start') {
        await initializeChatSession('start');
        return;
      } else {
        setMessages((prev) => [...prev, { role: 'model', text: `Unknown command: "Pitch Coach: ${commandSuffix}". Please use one of the specified modes.` }]);
        setIsLoading(false);
        return;
      }
    }

    // If no chat session is active, or if it's not a mode command
    if (!chatRef.current || !currentMode) {
      setMessages((prev) => [
        ...prev,
        { role: 'model', text: "Please start a Pitch Coach session by typing 'Pitch Coach: start' or click a mode button." },
      ]);
      setIsLoading(false);
      return;
    }

    try {
      const ai = getGoogleGenAIInstance();
      
      const response = await chatRef.current.sendMessageStream({ message: userMessage });
      let fullText = "";
      for await (const chunk of response) {
        fullText += chunk.text;
      }
      setMessages((prev) => [...prev, { role: 'model', text: fullText }]);
    } catch (error: any) {
      console.error('Error sending message to AI chat:', error);
      if (error.message === "API_KEY_UNDEFINED") {
        setMessages((prev) => [...prev, { role: 'system', text: 'API Key is missing. Please select your API key.' }]);
        setApiKeySelected(false);
      } else if (error.message.includes("Requested entity was not found.")) {
        setMessages((prev) => [...prev, { role: 'system', text: 'API Key issue detected. Please re-select your API key.' }]);
        setApiKeySelected(false); // Reset to prompt re-selection
      } else {
        setMessages((prev) => [...prev, { role: 'system', text: 'An error occurred while getting a response. Please try again or restart the session.' }]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="ai-coach-container section-container">
      <h2 className="section-title">Your AI-Powered Pitch Coach</h2>
      <p className="coach-intro">
        Use this script in conversation with me anytime. Just type: "Pitch Coach: start" and I'll become your real-time gym customer.
        You can also choose a mode:
      </p>

      {!apiKeySelected ? (
        <div className="api-key-prompt">
          <p>To use the AI Pitch Coach, you need to select an API key.</p>
          <button onClick={handleSelectApiKey} className="nav-button active">
            Select API Key
          </button>
          <p className="billing-info">
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer">
              Learn more about Gemini API billing.
            </a>
          </p>
        </div>
      ) : (
        <>
          <div className="mode-buttons">
            <button
                className={`mode-button ${currentMode === 'start' ? 'active' : ''}`}
                onClick={() => initializeChatSession('start')}
                disabled={isLoading}
                aria-label="Start basic pitch coach session"
              >
                Start Basic Session
            </button>
            {Object.keys(modeSystemInstructions).filter(modeKey => modeKey !== 'start').map((modeKey) => (
              <button
                key={modeKey}
                className={`mode-button ${currentMode === modeKey ? 'active' : ''}`}
                onClick={() => initializeChatSession(modeKey)}
                disabled={isLoading}
                aria-label={`Start ${modeKey} session`}
              >
                {modeKey.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
              </button>
            ))}
          </div>

          {currentMode && modeExamples[currentMode] && (
            <div className="transcript-display" style={{marginBottom: '15px', borderColor: '#424242'}}>
               <h4 style={{color: '#e0e0e0'}}>💡 Pitch Tip for {currentMode.charAt(0).toUpperCase() + currentMode.slice(1)}:</h4>
               <p style={{fontStyle: 'italic', color: '#bdbdbd'}}>{modeExamples[currentMode]}</p>
            </div>
          )}

          <div className="chat-window" role="log" aria-live="polite">
            {messages.map((msg, index) => (
              <div key={index} className={`chat-message ${msg.role}`}>
                <span className="chat-role">
                  {msg.role === 'user' ? 'You:' : msg.role === 'model' ? 'Coach:' : 'System:'}
                </span>
                <p>{msg.text}</p>
              </div>
            ))}
            {isLoading && (
              <div className="chat-message model loading">
                <span className="chat-role">Coach: </span>
                <p>Thinking...</p>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="chat-input-area">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={currentMode ? `Pitch for the "${currentMode}" mode...` : 'Type "Pitch Coach: start" or click a mode button to begin...'}
              disabled={isLoading || !apiKeySelected}
              aria-label="Your pitch or command"
              rows={3}
            />
            <button onClick={handleSendMessage} disabled={isLoading || !apiKeySelected} className="send-button" aria-label="Send message">
              {isLoading ? 'Sending...' : 'Send'}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default AIChatComponent;
