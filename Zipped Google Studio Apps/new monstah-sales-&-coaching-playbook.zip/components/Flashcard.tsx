
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

interface FlashcardProps {
  issue: string;
  solution: string;
}

declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

const MicIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '8px', verticalAlign: 'text-bottom' }}>
    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
    <line x1="12" y1="19" x2="12" y2="23"></line>
    <line x1="8" y1="23" x2="16" y2="23"></line>
  </svg>
);

const StopIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '8px', verticalAlign: 'text-bottom' }}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
  </svg>
);

const RobotIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '8px', verticalAlign: 'text-bottom' }}>
     <rect x="3" y="11" width="18" height="10" rx="2"></rect>
     <circle cx="12" cy="5" r="2"></circle>
     <path d="M12 7v4"></path>
     <line x1="8" y1="16" x2="8" y2="16"></line>
     <line x1="16" y1="16" x2="16" y2="16"></line>
  </svg>
);

const Flashcard: React.FC<FlashcardProps> = ({ issue, solution }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [micStatus, setMicStatus] = useState<string>('Ready');
  
  // Practice Mode States
  const [practiceMode, setPracticeMode] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiFeedback, setAiFeedback] = useState<{score: string, comment: string} | null>(null);

  const recognitionRef = useRef<InstanceType<typeof window.SpeechRecognition> | null>(null);

  const startListening = () => {
    setMicStatus('Initializing...');
    
    // 1. Check for HTTPS
    if (window.location.protocol !== 'https:' && window.location.hostname !== 'localhost') {
      setMicStatus('Error: HTTPS Required');
      return;
    }

    // 2. Check Browser Support
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setMicStatus('Error: Not Supported');
      return;
    }

    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      setMicStatus('Listening...');
      if (!practiceMode) setTranscript(''); // Only clear if starting fresh in normal mode
      // In practice mode, we might clear in the toggle handler, or keep previous attempts? Let's clear.
      if (practiceMode && !transcript) setTranscript('');
    };

    recognition.onresult = (event: any) => {
      let final = '';
      let interim = '';

      for (let i = 0; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          final += event.results[i][0].transcript;
        } else {
          interim += event.results[i][0].transcript;
        }
      }
      setTranscript(final + interim);
    };

    recognition.onerror = (event: any) => {
      if (event.error === 'no-speech') return;
      setIsListening(false);
      recognitionRef.current = null;
      if (event.error === 'not-allowed') setMicStatus('Access Denied');
      else setMicStatus(`Error: ${event.error}`);
    };

    recognition.onend = () => {
      if (isListening) {
          setIsListening(false);
          setMicStatus('Stopped');
          // If in practice mode and stopped, we might want to auto-trigger analysis? 
          // Better to let user click "Stop & Grade" to avoid premature submission.
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
    setMicStatus('Stopped');
  };

  const handleFlip = (e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    if (isFlipped) {
      stopListening();
    }
    setIsFlipped(!isFlipped);
  };

  // Practice Mode Toggle Logic
  const togglePracticeMode = () => {
    setPracticeMode(!practiceMode);
    setIsFlipped(false);
    setTranscript('');
    setAiFeedback(null);
    stopListening();
    setMicStatus('Ready');
  };

  // AI Grading Logic
  const gradeResponse = async () => {
    stopListening();
    
    if (!transcript.trim()) {
        setAiFeedback({score: '0', comment: 'No speech detected. Please try again.'});
        setIsFlipped(true);
        return;
    }

    setIsAnalyzing(true);

    try {
        // Ensure API Key
        if (!process.env.API_KEY) {
            // Attempt to trigger key selection if available
            if ((window as any).aistudio && (window as any).aistudio.openSelectKey) {
                await (window as any).aistudio.openSelectKey();
            }
            if (!process.env.API_KEY) throw new Error("API Key Missing");
        }

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `You are a strict sales coach evaluating a trainee's response to a customer objection.
        
        Objection: "${issue}"
        Ideal Solution: "${solution}"
        Trainee Response: "${transcript}"

        Task: Compare the Trainee Response to the Ideal Solution. 
        1. Give a score from 1-10 based on how well they handled the objection.
        2. Provide a 1-sentence helpful critique or praise.

        Output strictly JSON: { "score": "number", "comment": "string" }`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { responseMimeType: 'application/json' }
        });

        const text = response.text;
        if (text) {
            const result = JSON.parse(text);
            setAiFeedback(result);
        } else {
            throw new Error("Empty response");
        }

    } catch (error) {
        console.error("AI Grading Error", error);
        setAiFeedback({score: '-', comment: 'Could not connect to AI Coach. Check API Key.'});
    } finally {
        setIsAnalyzing(false);
        setIsFlipped(true); // Reveal card with feedback
    }
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  useEffect(() => {
    setIsFlipped(false);
    stopListening();
    setMicStatus('Ready');
    setTranscript('');
    setAiFeedback(null);
  }, [issue, solution]);

  return (
    <div className={`flashcard ${isFlipped ? 'flipped' : ''}`} aria-live="polite">
      <div className="flashcard-scene">
        <div className="flashcard-card">
          {/* Front Face */}
          <div className="flashcard-face flashcard-front" aria-hidden={isFlipped}>
            
            <div className="practice-mode-toggle-container">
                 <label className="toggle-label">
                    <input 
                        type="checkbox" 
                        checked={practiceMode} 
                        onChange={togglePracticeMode} 
                        className="toggle-checkbox"
                    />
                    <span className="toggle-switch"></span>
                    <span className="toggle-text">Practice Mode</span>
                 </label>
            </div>

            <div className="flashcard-content-wrapper">
              <p className="flashcard-label-issue">❌ Objection</p>
              <p className="flashcard-text" aria-atomic="true">{issue}</p>
              
              {/* Practice Mode: Live Transcript on Front */}
              {practiceMode && (
                  <div className={`front-transcript-box ${isListening ? 'active' : ''}`}>
                      {transcript || (isListening ? "Listening..." : "Tap Record to answer...")}
                  </div>
              )}
            </div>

            {!practiceMode ? (
                <button
                onClick={handleFlip}
                className="flashcard-flip-button"
                aria-label="Reveal solution"
                >
                Reveal Answer
                </button>
            ) : (
                <div className="practice-buttons">
                    {!isListening ? (
                         <button
                         onClick={startListening}
                         className="flashcard-flip-button"
                         disabled={isAnalyzing}
                         >
                            <MicIcon /> Record Response
                         </button>
                    ) : (
                        <button
                        onClick={gradeResponse}
                        className="flashcard-flip-button stop mic-active"
                        >
                           <StopIcon /> Stop & Grade
                        </button>
                    )}
                    {isAnalyzing && <span className="analyzing-text">Analyzing...</span>}
                </div>
            )}
          </div>

          {/* Back Face */}
          <div className="flashcard-face flashcard-back" aria-hidden={!isFlipped}>
            <div className="flashcard-content-wrapper">
              
              {/* If we have AI Feedback, show it prominently */}
              {aiFeedback && practiceMode ? (
                 <div className="ai-feedback-container">
                    <div className="ai-header">
                        <span className="ai-score-badge">Score: {aiFeedback.score}/10</span>
                        <span className="ai-label">AI Coach Feedback</span>
                    </div>
                    <p className="ai-comment">{aiFeedback.comment}</p>
                 </div>
              ) : null}

              <p className="flashcard-label-solution">✔ Solution</p>
              <p className="flashcard-text" aria-atomic="true">{solution}</p>
              
              <div className="practice-area">
                {/* Standard Practice Area (Always visible on back) */}
                {!practiceMode && (
                    <>
                        <h3>Practice Your Response:</h3>
                        <div style={{ 
                            marginBottom: '10px', 
                            fontSize: '0.9em', 
                            color: micStatus.includes('Error') ? '#ff5252' : '#bdbdbd',
                        }}>
                            Status: {micStatus}
                        </div>
                        <div className="practice-buttons">
                        {!isListening ? (
                            <button
                            onClick={startListening}
                            className="flashcard-practice-button start"
                            disabled={!isFlipped}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                            >
                            <MicIcon /> Start Voice Practice
                            </button>
                        ) : (
                            <button
                            onClick={stopListening}
                            className="flashcard-practice-button stop mic-active"
                            disabled={!isFlipped}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                            >
                            <StopIcon /> Stop Practice
                            </button>
                        )}
                        </div>
                        {transcript && (
                            <div className="transcript-display">
                                <h4>Your Transcription:</h4>
                                <p>{transcript}</p>
                            </div>
                        )}
                    </>
                )}

                {/* In Practice Mode, just show what they said if feedback is displayed */}
                {practiceMode && transcript && (
                     <div className="transcript-display">
                        <h4>You Said:</h4>
                        <p>{transcript}</p>
                    </div>
                )}
              </div>
            </div>
            <button
              onClick={handleFlip}
              className="flashcard-flip-button secondary"
              aria-label="Hide solution"
              tabIndex={!isFlipped ? -1 : 0}
            >
              {practiceMode ? "Try Next / Reset" : "Hide Answer"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Flashcard;
