
import React from 'react';
import { productStories } from '../data';

const StoriesSection: React.FC = () => {
  return (
    <section className="section-container" aria-labelledby="stories-section-title">
      <h2 id="stories-section-title" className="section-title">Product Storytelling Scripts for Every Monstah Item</h2>
      <div className="product-stories-list">
        {productStories.map((item, index) => (
          <details key={index} className="product-story-details">
            <summary className="product-story-summary">
              {item.product}
            </summary>
            <p className="product-story-text">{item.story}</p>
          </details>
        ))}
      </div>
    </section>
  );
};

export default StoriesSection;