
import React, { useState, useEffect, useMemo } from 'react';
import Flashcard from './Flashcard';
import { Flashcard as FlashcardData, flashcards } from '../data';

const FlashcardSection: React.FC = () => {
  const categories = useMemo(() => {
    const uniqueCategories = new Set<string>();
    flashcards.forEach((card) => uniqueCategories.add(card.category));
    return Array.from(uniqueCategories);
  }, []);

  const [selectedCategory, setSelectedCategory] = useState<string>(categories[0] || '');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);

  const filteredFlashcards = useMemo(() => {
    return flashcards.filter((card) => card.category === selectedCategory);
  }, [selectedCategory]);

  useEffect(() => {
    setCurrentCardIndex(0); // Reset index when category changes
  }, [selectedCategory]);

  const handleNext = () => {
    setCurrentCardIndex((prevIndex) => (prevIndex + 1) % filteredFlashcards.length);
  };

  const handlePrevious = () => {
    setCurrentCardIndex((prevIndex) =>
      prevIndex === 0 ? filteredFlashcards.length - 1 : prevIndex - 1,
    );
  };

  if (!filteredFlashcards.length) {
    return <div className="section-container">No flashcards available for this category.</div>;
  }

  const currentFlashcard = filteredFlashcards[currentCardIndex];

  return (
    <section className="section-container" aria-labelledby="flashcard-section-title">
      <h2 id="flashcard-section-title" className="section-title">Objections Flashcards</h2>

      <div className="category-selector">
        <label htmlFor="category-select" className="sr-only">Select Category:</label>
        <select
          id="category-select"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          aria-controls="flashcard-display"
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      <div id="flashcard-display" className="flashcard-display-area">
        <Flashcard issue={currentFlashcard.issue} solution={currentFlashcard.solution} />

        <div className="flashcard-navigation">
          <button
            onClick={handlePrevious}
            className="nav-button"
            aria-label="Previous flashcard"
          >
            Previous
          </button>
          <span className="card-counter" aria-live="polite">
            {currentCardIndex + 1} / {filteredFlashcards.length}
          </span>
          <button
            onClick={handleNext}
            className="nav-button"
            aria-label="Next flashcard"
          >
            Next
          </button>
        </div>
      </div>
    </section>
  );
};

export default FlashcardSection;