
import React from 'react';
import { openerScripts } from '../data';

const OpenersSection: React.FC = () => {
  return (
    <section className="section-container" aria-labelledby="openers-section-title">
      <h2 id="openers-section-title" className="section-title">10 Openers Optimized for Gym Floor Selling</h2>
      <ol className="openers-list">
        {openerScripts.map((opener, index) => (
          <li key={index} className="opener-item">{opener}</li>
        ))}
      </ol>
    </section>
  );
};

export default OpenersSection;