import { GoogleGenAI, Modality } from "@google/genai";
import { Character } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getStyleInstruction = (style: string): string => {
  switch (style) {
    case 'Cyberpunk':
      return 'Generate the image in a vibrant, high-contrast cyberpunk style with neon lights, futuristic cityscapes, and cybernetic elements.';
    case 'Anime':
      return 'Generate the image in a classic 90s anime style, with detailed hand-drawn aesthetics, film grain, and expressive characters.';
    case 'Watercolor Painting':
      return 'Generate the image as a beautiful watercolor painting with soft edges, blended colors, and a textured paper look.';
    case 'Cinematic':
      return 'Generate the image in a cinematic style with dramatic lighting, a shallow depth of field, and a widescreen aspect ratio feel. The colors should be rich and moody.';
    case 'Glitch Art':
      return 'Generate the image in a glitch art style, with digital artifacts, scan lines, color aberrations, and a distorted, chaotic aesthetic.';
    case 'Pop Surrealism':
      return 'Generate the image in a Pop Surrealism (or Lowbrow) style, featuring cartoonish, big-eyed figures in a whimsical or bizarre, dream-like setting. The colors should be vibrant and saturated.';
    case 'Art Deco Revival':
      return 'Generate the image in an elegant Art Deco Revival style, characterized by bold geometric patterns, symmetrical designs, rich colors, and a glamorous, vintage 1920s feel.';
    case 'Abstract Data Art':
      return 'Generate the image in an Abstract Data Art style, using algorithms and data visualization principles to create complex, geometric, and colorful compositions.';
    case 'Kinetic Art':
      return 'Generate the image in a Kinetic Art style, creating a sense of movement, vibration, or optical illusion through patterns, lines, and composition.';
    case 'ASCII Art Overlay':
      return 'Generate the image with a creative ASCII art overlay. The underlying image should be clear, but with a stylized layer of text characters forming the visual details.';
    case 'Synesthesia Art':
      return 'Generate the image in a Synesthesia Art style, translating abstract concepts or emotions into a vibrant explosion of interconnected colors, shapes, and textures.';
    case 'Sumi-e Art':
      return 'Generate the image in a traditional Japanese Sumi-e (ink wash) style, emphasizing minimalist beauty, flowing brushstrokes, and a monochromatic palette with subtle gradients.';
    case 'Low Poly 3D':
      return 'Generate the image in a Low Poly 3D style, featuring a faceted, geometric look as if constructed from a 3D mesh with flat-shaded polygons. Colors should be clean and vibrant.';
    case 'Default':
    default:
      return 'Generate the image in a consistent, high-quality cartoon style.';
  }
}

export const generateImage = async (
  prompt: string,
  referenceCharacters: Character[],
  aspectRatio: string,
  imageStyle: string
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash-image';
    const selectedCharacters = referenceCharacters.filter(c => c.selected && c.image);

    const characterDefinitions = selectedCharacters
      .map(c => c.name)
      .join(', ');
    
    const styleInstruction = getStyleInstruction(imageStyle);
    
    const fullPrompt = `
      You are an AI assistant creating a set of story images with consistent characters.
      Reference the following characters: ${characterDefinitions || 'the character(s) described'}.
      
      Scene Prompt: "${prompt}"

      Style instructions:
      - ${styleInstruction}
      - Ensure the characters look the same as in the provided reference images.
      - The image must be in 4K resolution and highly detailed.
      - The aspect ratio must be ${aspectRatio}.
    `;

    const imageParts = selectedCharacters.map(c => ({
      inlineData: {
        data: c.image!,
        mimeType: c.mimeType!,
      },
    }));

    const parts: any[] = [
      { text: fullPrompt },
      ...imageParts,
    ];

    const response = await ai.models.generateContent({
      model: model,
      contents: { parts },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }

    throw new Error("No image data found in the API response.");

  } catch (error) {
    console.error("Error generating image with Gemini:", error);
    throw new Error("Failed to generate image. Please check the console for details.");
  }
};