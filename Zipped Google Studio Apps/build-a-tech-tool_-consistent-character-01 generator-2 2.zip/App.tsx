import React, { useState, useCallback } from 'react';
import { Character, GeneratedImage, AspectRatio } from './types';
import { fileToBase64, downloadImage, getFormattedDate } from './utils/fileUtils';
import { generateImage } from './services/geminiService';

// --- Helper & Icon Components (defined outside main component) ---

const UploadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
  </svg>
);

const DownloadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

const PreviewIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
        <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
    </svg>
);


interface CharacterSlotProps {
  character: Character;
  onUpdate: (character: Character) => void;
}

const CharacterSlot: React.FC<CharacterSlotProps> = ({ character, onUpdate }) => {
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const { base64, mimeType } = await fileToBase64(file);
      onUpdate({ ...character, image: base64, mimeType });
    }
  };

  return (
    <div className="bg-base-300 p-4 rounded-lg flex items-center space-x-4">
      <input
        type="checkbox"
        className="form-checkbox h-5 w-5 text-brand-primary bg-base-100 border-base-content rounded focus:ring-brand-secondary"
        checked={character.selected}
        onChange={(e) => onUpdate({ ...character, selected: e.target.checked })}
      />
      <div className="flex-1 min-w-0">
        <input
          type="text"
          value={character.name}
          onChange={(e) => onUpdate({ ...character, name: e.target.value })}
          className="w-full bg-base-100 text-base-content font-semibold p-1 rounded border border-transparent focus:outline-none focus:ring-2 focus:ring-brand-primary"
        />
      </div>
      <label className="cursor-pointer">
        <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
        {character.image ? (
          <img src={`data:${character.mimeType};base64,${character.image}`} alt={character.name} className="w-16 h-16 object-cover rounded-md border-2 border-base-200" />
        ) : (
          <div className="w-16 h-16 bg-base-200 rounded-md flex items-center justify-center text-gray-400 hover:bg-brand-primary/20 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
          </div>
        )}
      </label>
    </div>
  );
};

interface ImageCardProps {
    image: GeneratedImage;
    index: number;
    onPreview: (base64: string) => void;
}

const ImageCard: React.FC<ImageCardProps> = ({ image, index, onPreview }) => {
    const filename = `${String(index + 1).padStart(3, '0')}_${getFormattedDate()}.png`;

    return (
        <div className="relative group aspect-square bg-base-200 rounded-lg overflow-hidden shadow-lg">
            <img src={`data:image/png;base64,${image.base64}`} alt={image.prompt} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-4">
                <button onClick={() => onPreview(image.base64)} className="p-3 bg-white/20 rounded-full text-white hover:bg-white/30 transition-colors backdrop-blur-sm">
                    <PreviewIcon />
                </button>
                <button onClick={() => downloadImage(image.base64, filename)} className="p-3 bg-white/20 rounded-full text-white hover:bg-white/30 transition-colors backdrop-blur-sm">
                    <DownloadIcon />
                </button>
            </div>
        </div>
    );
};

interface ModalProps {
    imageUrl: string | null;
    onClose: () => void;
}

const Modal: React.FC<ModalProps> = ({ imageUrl, onClose }) => {
    if (!imageUrl) return null;

    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="relative max-w-4xl max-h-full" onClick={(e) => e.stopPropagation()}>
                <img src={`data:image/png;base64,${imageUrl}`} alt="Preview" className="max-w-full max-h-[90vh] object-contain rounded-lg" />
                <button onClick={onClose} className="absolute -top-4 -right-4 bg-base-100 text-white rounded-full h-10 w-10 flex items-center justify-center text-2xl">&times;</button>
            </div>
        </div>
    );
};

// --- Main App Component ---

const App: React.FC = () => {
  const [characters, setCharacters] = useState<Character[]>([
    { id: 1, name: 'Character 1', image: null, mimeType: null, selected: false },
    { id: 2, name: 'Character 2', image: null, mimeType: null, selected: false },
    { id: 3, name: 'Character 3', image: null, mimeType: null, selected: false },
    { id: 4, name: 'Character 4', image: null, mimeType: null, selected: false },
  ]);
  const [imageStyle, setImageStyle] = useState('Default');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [customRatio, setCustomRatio] = useState({ width: 1, height: 1 });
  const [prompts, setPrompts] = useState('');
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [modalImage, setModalImage] = useState<string | null>(null);

  const handleCharacterUpdate = (updatedCharacter: Character) => {
    setCharacters(
      characters.map((c) => (c.id === updatedCharacter.id ? updatedCharacter : c))
    );
  };

  const getAspectRatioString = () => {
    if (aspectRatio === 'Custom') {
        return `${customRatio.width}:${customRatio.height}`;
    }
    return aspectRatio;
  }
  
  const handleGenerateAll = async () => {
    const parsedPrompts = prompts.split(/[\n,]/).map(p => p.trim()).filter(p => p.length > 0);
    if (parsedPrompts.length === 0) {
      alert('Please enter at least one prompt.');
      return;
    }
    const selectedCharacters = characters.filter(c => c.selected && c.image);
    if (selectedCharacters.length === 0) {
      alert('Please upload and select at least one character reference image.');
      return;
    }

    setIsLoading(true);
    setGeneratedImages([]);

    const generationPromises = parsedPrompts.map((prompt, index) =>
      generateImage(prompt, selectedCharacters, getAspectRatioString(), imageStyle)
        .then(base64 => ({ id: index, prompt, base64 }))
        .catch(err => {
            console.error(`Failed to generate image for prompt: "${prompt}"`, err);
            return null;
        })
    );

    const results = await Promise.all(generationPromises);
    const successfulImages = results.filter(r => r !== null) as GeneratedImage[];
    setGeneratedImages(successfulImages);
    
    setIsLoading(false);
  };

  const handleDownloadAll = () => {
    if (generatedImages.length === 0) return;
    generatedImages.forEach((image, index) => {
        setTimeout(() => {
            const filename = `${String(index + 1).padStart(3, '0')}_${getFormattedDate()}.png`;
            downloadImage(image.base64, filename);
        }, index * 200); // Stagger downloads to avoid browser blocking
    });
  };

  return (
    <>
      <div className="min-h-screen flex flex-col md:flex-row">
        {/* Left Column - Control Panel */}
        <aside className="w-full md:w-1/3 lg:w-1/4 bg-base-200 p-6 space-y-6 overflow-y-auto min-h-screen">
          <h1 className="text-3xl font-bold text-base-content">Character Creator</h1>
          
          <div>
            <h2 className="text-xl font-semibold mb-3">1. Character References</h2>
            <div className="space-y-3">
              {characters.map((char) => (
                <CharacterSlot key={char.id} character={char} onUpdate={handleCharacterUpdate} />
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">2. Image Style</h2>
            <select
              value={imageStyle}
              onChange={(e) => setImageStyle(e.target.value)}
              className="w-full p-2 bg-base-300 rounded border border-base-300 focus:outline-none focus:ring-2 focus:ring-brand-primary"
            >
              <option>Default</option>
              <option>Cyberpunk</option>
              <option>Anime</option>
              <option>Watercolor Painting</option>
              <option>Cinematic</option>
              <option>Glitch Art</option>
              <option>Pop Surrealism</option>
              <option>Art Deco Revival</option>
              <option>Abstract Data Art</option>
              <option>Kinetic Art</option>
              <option>ASCII Art Overlay</option>
              <option>Synesthesia Art</option>
              <option>Sumi-e Art</option>
              <option>Low Poly 3D</option>
            </select>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">3. Aspect Ratio</h2>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
              className="w-full p-2 bg-base-300 rounded border border-base-300 focus:outline-none focus:ring-2 focus:ring-brand-primary"
            >
              <option>1:1</option>
              <option>16:9</option>
              <option>9:16</option>
              <option>4:3</option>
              <option>Custom</option>
            </select>
            {aspectRatio === 'Custom' && (
                <div className="flex items-center space-x-2 mt-2">
                    <input type="number" value={customRatio.width} onChange={e => setCustomRatio({...customRatio, width: parseInt(e.target.value) || 1})} className="w-full p-2 bg-base-300 rounded" />
                    <span className="font-bold">:</span>
                    <input type="number" value={customRatio.height} onChange={e => setCustomRatio({...customRatio, height: parseInt(e.target.value) || 1})} className="w-full p-2 bg-base-300 rounded" />
                </div>
            )}
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">4. Prompt List</h2>
            <p className="text-sm text-gray-400 mb-2">Enter up to 10 prompts, separated by a new line or comma.</p>
            <textarea
              value={prompts}
              onChange={(e) => setPrompts(e.target.value)}
              placeholder={`Character 1 running in the park\nCharacter 1 and 2 eating ice cream...`}
              rows={10}
              className="w-full p-3 bg-base-300 text-base-content rounded border border-base-300 focus:outline-none focus:ring-2 focus:ring-brand-primary"
            />
          </div>

          <button
            onClick={handleGenerateAll}
            disabled={isLoading}
            className="w-full bg-brand-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-brand-secondary transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
              </>
            ) : (
              'Generate All Images'
            )}
          </button>
        </aside>

        {/* Right Column - Results Display */}
        <main className="w-full md:w-2/3 lg:w-3/4 p-6 overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Results</h2>
            {generatedImages.length > 0 && (
              <button
                onClick={handleDownloadAll}
                className="bg-base-300 hover:bg-base-200 text-base-content font-semibold py-2 px-4 rounded-lg flex items-center"
              >
                <DownloadIcon />
                <span className="ml-2">Download All</span>
              </button>
            )}
          </div>

          {isLoading && generatedImages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-400">
                <svg className="animate-spin h-12 w-12 text-brand-primary mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <p className="text-xl">Generating your masterpieces...</p>
                <p>This may take a few moments.</p>
            </div>
          )}

          {!isLoading && generatedImages.length === 0 && (
            <div className="flex items-center justify-center h-full text-center border-2 border-dashed border-base-300 rounded-lg">
                <div className="text-gray-500">
                    <h3 className="text-xl font-semibold">Your generated images will appear here.</h3>
                    <p>Set up your characters and prompts to get started.</p>
                </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4">
            {generatedImages.map((image, index) => (
              <ImageCard key={image.id} image={image} index={index} onPreview={setModalImage} />
            ))}
          </div>
        </main>
      </div>
      <Modal imageUrl={modalImage} onClose={() => setModalImage(null)} />
    </>
  );
};

export default App;