
export const DEFAULT_VOICES = [
    { id: 'Kore', name: 'Kore (Female, Warm)' },
    { id: 'Puck', name: 'Puck (Male, Crisp)' },
    { id: 'Charon', name: 'Charon (Male, Deep)' },
    { id: 'Fenrir', name: 'Fenrir (Male, Raspy)' },
    { id: 'Zephyr', name: 'Zephyr (Female, Gentle)' },
    { id: 'Aether', name: 'Aether (Male, Authoritative)' },
    { id: 'Ember', name: 'Ember (Female, Energetic)' },
    { id: 'Sol', name: 'Sol (Male, Soothing)' },
    { id: 'Luna', name: 'Luna (Female, Storyteller)' },
    { id: 'Titan', name: 'Titan (Male, Announcer)' },
    { id: 'Aura', name: 'Aura (Female, Calm)' },
    { id: 'Orion', name: 'Orion (Male, Youthful)' },
    { id: 'Lyra', name: 'Lyra (Female, Youthful)' },
];

export const EMOTIONS = [
    { value: 'normal', label: 'Normal' },
    { value: 'happy', label: 'Happy' },
    { value: 'sad', label: 'Sad' },
    { value: 'angry', label: 'Angry' },
    { value: 'surprised', label: 'Surprised' },
    { value: 'calm', label: 'Calm' },
];
